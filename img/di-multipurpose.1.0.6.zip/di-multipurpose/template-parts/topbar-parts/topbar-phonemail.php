<?php
/**
 * Will contain phone, email and address.
 */
?>

<div class="spsl-topbar-left-cntr">

	<p class="tpbr_lft_phne_ctmzr">
		<?php
		get_template_part( 'template-parts/partial/topbar', 'phonemail' );
		?>
	</p>

</div>
					