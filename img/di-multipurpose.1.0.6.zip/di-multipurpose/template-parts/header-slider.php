<?php
do_action( 'di_multipurpose_header_slider_file' );
