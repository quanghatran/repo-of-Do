<?php
do_action( 'di_multipurpose_hdrimg_file' );
