<div class="di-post-thumb">
	<?php
	di_multipurpose_post_thumbnail();
	?>
</div>