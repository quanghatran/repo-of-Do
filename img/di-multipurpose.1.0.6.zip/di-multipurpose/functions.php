<?php

// Return if accessed this file directly.
if( ! defined( 'ABSPATH' ) ) {
	return;
}

// Load init.php file.
require_once get_template_directory() . '/inc/init.php';

/*
* Do not edit any code of theme, use child theme instead
*/
