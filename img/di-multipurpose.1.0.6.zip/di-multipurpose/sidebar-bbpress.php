<div class="col-md-4">
	<div class="right-content" >
		<?php
		if( is_active_sidebar( 'sidebar_bbpress' ) ) {
			dynamic_sidebar( 'sidebar_bbpress' );
		}
		?>
	</div>
</div>
