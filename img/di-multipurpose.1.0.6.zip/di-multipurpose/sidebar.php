<div class="col-md-4">
	<div class="right-content" >
		<?php
		do_action( 'di_multipurpose_post_sidebar_file' );
		?>
	</div>
</div>
